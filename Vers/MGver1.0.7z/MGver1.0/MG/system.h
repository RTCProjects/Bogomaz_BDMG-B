#ifndef _SYSTEM_H
#define _SYSTEM_H

#include "main.h"

uint8	System_RAMTest(void);
void	System_Delay(unsigned long z);
void	System_Reset(void);
#endif
